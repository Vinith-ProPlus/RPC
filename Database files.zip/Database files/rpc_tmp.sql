-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2024 at 12:24 PM
-- Server version: 11.3.0-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rpc_tmp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `ProductID` varchar(50) NOT NULL,
  `Slug` varchar(160) DEFAULT NULL,
  `ProductName` varchar(150) DEFAULT NULL,
  `ProductType` enum('Simple','Variable') DEFAULT 'Simple',
  `ProductCode` varchar(50) DEFAULT NULL,
  `Stages` text DEFAULT NULL,
  `HSNSAC` varchar(50) DEFAULT NULL,
  `CID` varchar(50) DEFAULT NULL,
  `SCID` varchar(50) DEFAULT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `TaxType` enum('Exclude','Include') DEFAULT 'Exclude',
  `TaxID` varchar(50) DEFAULT NULL,
  `PRate` double DEFAULT 0,
  `SRate` double DEFAULT 0,
  `Decimals` enum('auto','0','1','2','3','4','5','6','7','8','9') DEFAULT 'auto',
  `Description` text DEFAULT NULL,
  `ShortDescription` text DEFAULT NULL,
  `Attributes` text DEFAULT NULL,
  `Images` text DEFAULT NULL,
  `ProductBrochure` text DEFAULT NULL,
  `VideoURL` text DEFAULT NULL,
  `gallery` text DEFAULT NULL,
  `ActiveStatus` enum('Active','Inactive') DEFAULT 'Active',
  `DFlag` int(1) DEFAULT 0,
  `CreatedOn` timestamp NULL DEFAULT current_timestamp(),
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedOn` timestamp NULL DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  `DeletedOn` timestamp NULL DEFAULT NULL,
  `DeletedBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`ProductID`, `Slug`, `ProductName`, `ProductType`, `ProductCode`, `Stages`, `HSNSAC`, `CID`, `SCID`, `UID`, `TaxType`, `TaxID`, `PRate`, `SRate`, `Decimals`, `Description`, `ShortDescription`, `Attributes`, `Images`, `ProductBrochure`, `VideoURL`, `gallery`, `ActiveStatus`, `DFlag`, `CreatedOn`, `CreatedBy`, `UpdatedOn`, `UpdatedBy`, `DeletedOn`, `DeletedBy`) VALUES
('20240313105541-I4ZSCXWLzQZY0XzJsn9z', 'test-product', 'Test Product', 'Variable', NULL, 'a:2:{i:0;s:14:\"SG2024-0000001\";i:1;s:14:\"SG2024-0000002\";}', NULL, 'PC2023-0000001', 'PSC2023-0000001', 'UOM2023-0000001', 'Exclude', 'TX2023-0000002', 100, 120, '3', NULL, NULL, 'a:1:{s:14:\"AT2023-0000001\";a:2:{s:11:\"isVariation\";b:1;s:4:\"data\";a:5:{i:0;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000001\";s:5:\"Value\";s:21:\"Multi-wall Paper Bags\";}i:1;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000002\";s:5:\"Value\";s:17:\"Polyethylene Bags\";}i:2;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000003\";s:5:\"Value\";s:28:\"Paper-Plastic Laminated Bags\";}i:3;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000004\";s:5:\"Value\";s:24:\"Woven Polypropylene Bags\";}i:4;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000005\";s:5:\"Value\";s:40:\"Kraft Paper Bags with Polyethylene Liner\";}}}}', 'a:2:{s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}', 'a:2:{s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}', NULL, 'a:0:{}', 'Active', 0, '2024-03-13 05:25:41', 'U2023-0000001', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products_variation`
--

CREATE TABLE `tbl_products_variation` (
  `VariationID` varchar(50) NOT NULL,
  `UUID` varchar(100) DEFAULT NULL,
  `ProductID` varchar(50) DEFAULT NULL,
  `Slug` text DEFAULT NULL,
  `Title` varchar(150) DEFAULT NULL,
  `PRate` double DEFAULT 0,
  `SRate` double DEFAULT 0,
  `Images` text DEFAULT NULL,
  `Attributes` text DEFAULT NULL,
  `CombinationID` text DEFAULT NULL,
  `DFlag` int(1) DEFAULT 0,
  `CreatedOn` timestamp NULL DEFAULT current_timestamp(),
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedOn` timestamp NULL DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  `DeletedOn` timestamp NULL DEFAULT NULL,
  `DeletedBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_products_variation`
--

INSERT INTO `tbl_products_variation` (`VariationID`, `UUID`, `ProductID`, `Slug`, `Title`, `PRate`, `SRate`, `Images`, `Attributes`, `CombinationID`, `DFlag`, `CreatedOn`, `CreatedBy`, `UpdatedOn`, `UpdatedBy`, `DeletedOn`, `DeletedBy`) VALUES
('20240313105543-5itIn5yREq3Mm8FeAefF', 'Ie1eb83e4c4-09', '20240313105541-I4ZSCXWLzQZY0XzJsn9z', 'test-product-multiwall-paper-bags', 'Test Product  - Multi-wall Paper Bags', 100, 120, 'a:2:{s:5:\"cover\";a:3:{s:3:\"url\";s:0:\"\";s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}s:7:\"gallery\";a:0:{}}', 'a:2:{s:4:\"data\";a:1:{i:0;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000001\";s:5:\"Value\";s:21:\"Multi-wall Paper Bags\";}}s:8:\"ValueIDs\";a:1:{i:0;s:15:\"ATV2023-0000001\";}}', 'ATV2023-0000001', 0, '2024-03-13 05:25:43', 'U2023-0000001', NULL, NULL, NULL, NULL),
('20240313105543-cADjAtZxDZZ3e7hLq9PX', 'Ib20e4c0341-1c', '20240313105541-I4ZSCXWLzQZY0XzJsn9z', 'test-product-paperplastic-laminated-bags', 'Test Product  - Paper-Plastic Laminated Bags', 100, 120, 'a:2:{s:5:\"cover\";a:3:{s:3:\"url\";s:0:\"\";s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}s:7:\"gallery\";a:0:{}}', 'a:2:{s:4:\"data\";a:1:{i:0;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000003\";s:5:\"Value\";s:28:\"Paper-Plastic Laminated Bags\";}}s:8:\"ValueIDs\";a:1:{i:0;s:15:\"ATV2023-0000003\";}}', 'ATV2023-0000003', 0, '2024-03-13 05:25:43', 'U2023-0000001', NULL, NULL, NULL, NULL),
('20240313105543-h3A1vPwZGfLXHVteilDr', 'Ia897ed3575-f1', '20240313105541-I4ZSCXWLzQZY0XzJsn9z', 'test-product-woven-polypropylene-bags', 'Test Product  - Woven Polypropylene Bags', 100, 120, 'a:2:{s:5:\"cover\";a:3:{s:3:\"url\";s:0:\"\";s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}s:7:\"gallery\";a:0:{}}', 'a:2:{s:4:\"data\";a:1:{i:0;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000004\";s:5:\"Value\";s:24:\"Woven Polypropylene Bags\";}}s:8:\"ValueIDs\";a:1:{i:0;s:15:\"ATV2023-0000004\";}}', 'ATV2023-0000004', 0, '2024-03-13 05:25:43', 'U2023-0000001', NULL, NULL, NULL, NULL),
('20240313105543-Q8UruyxkZ65BkYQvMFk8', 'I95fe378369-c4', '20240313105541-I4ZSCXWLzQZY0XzJsn9z', 'test-product-polyethylene-bags', 'Test Product  - Polyethylene Bags', 100, 120, 'a:2:{s:5:\"cover\";a:3:{s:3:\"url\";s:0:\"\";s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}s:7:\"gallery\";a:0:{}}', 'a:2:{s:4:\"data\";a:1:{i:0;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000002\";s:5:\"Value\";s:17:\"Polyethylene Bags\";}}s:8:\"ValueIDs\";a:1:{i:0;s:15:\"ATV2023-0000002\";}}', 'ATV2023-0000002', 0, '2024-03-13 05:25:43', 'U2023-0000001', NULL, NULL, NULL, NULL),
('20240313105543-tW9Dlhh7xZmNIR4IysNn', 'Ie6733d1715-56', '20240313105541-I4ZSCXWLzQZY0XzJsn9z', 'test-product-kraft-paper-bags-with-polyethylene-liner', 'Test Product  - Kraft Paper Bags with Polyethylene Liner', 100, 120, 'a:2:{s:5:\"cover\";a:3:{s:3:\"url\";s:0:\"\";s:9:\"isDeleted\";i:0;s:4:\"data\";a:0:{}}s:7:\"gallery\";a:0:{}}', 'a:2:{s:4:\"data\";a:1:{i:0;a:2:{s:7:\"ValueID\";s:15:\"ATV2023-0000005\";s:5:\"Value\";s:40:\"Kraft Paper Bags with Polyethylene Liner\";}}s:8:\"ValueIDs\";a:1:{i:0;s:15:\"ATV2023-0000005\";}}', 'ATV2023-0000005', 0, '2024-03-13 05:25:43', 'U2023-0000001', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_save_status`
--

CREATE TABLE `tbl_product_save_status` (
  `UserID` varchar(50) NOT NULL,
  `Percentage` double DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors`
--

CREATE TABLE `tbl_vendors` (
  `VendorID` varchar(50) NOT NULL,
  `VendorName` varchar(150) DEFAULT NULL,
  `VendorCoName` text DEFAULT NULL,
  `VendorCoWebsite` text DEFAULT NULL,
  `Reference` text DEFAULT NULL,
  `GSTNo` varchar(50) DEFAULT NULL,
  `PCategories` text DEFAULT NULL,
  `VendorType` varchar(50) DEFAULT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `MobileNumber1` varchar(50) DEFAULT NULL,
  `MobileNumber2` varchar(50) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `PostalCode` varchar(50) DEFAULT NULL,
  `CityID` varchar(50) DEFAULT NULL,
  `TalukID` varchar(50) DEFAULT NULL,
  `DistrictID` varchar(50) DEFAULT NULL,
  `StateID` varchar(50) DEFAULT NULL,
  `CountryID` varchar(50) DEFAULT NULL,
  `Logo` text DEFAULT NULL,
  `CreatedOn` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vendors`
--

INSERT INTO `tbl_vendors` (`VendorID`, `VendorName`, `VendorCoName`, `VendorCoWebsite`, `Reference`, `GSTNo`, `PCategories`, `VendorType`, `Email`, `MobileNumber1`, `MobileNumber2`, `Address`, `PostalCode`, `CityID`, `TalukID`, `DistrictID`, `StateID`, `CountryID`, `Logo`, `CreatedOn`) VALUES
('111', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6583927956', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-02-08 17:35:49'),
('V2024-00000025', NULL, NULL, NULL, NULL, NULL, NULL, 'ST2023-0000002', NULL, '9565588282', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-02-09 11:58:43'),
('V2024-00000041', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '6868655242', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-02-09 18:17:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors_service_locations`
--

CREATE TABLE `tbl_vendors_service_locations` (
  `SNo` int(11) NOT NULL,
  `VendorID` varchar(50) DEFAULT NULL,
  `ServiceBy` enum('District','PostalCode','Radius') NOT NULL DEFAULT 'PostalCode',
  `Latitude` varchar(100) DEFAULT NULL,
  `Longitude` varchar(100) DEFAULT NULL,
  `Raduis` int(50) DEFAULT NULL,
  `PostalCodeID` varchar(50) DEFAULT NULL,
  `DistrictID` varchar(50) DEFAULT NULL,
  `StateID` varchar(50) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vendors_service_locations`
--

INSERT INTO `tbl_vendors_service_locations` (`SNo`, `VendorID`, `ServiceBy`, `Latitude`, `Longitude`, `Raduis`, `PostalCodeID`, `DistrictID`, `StateID`, `CreatedOn`) VALUES
(359, '111', 'District', NULL, NULL, NULL, NULL, 'DT2023-00000497', 'S2020-00000035', '2024-02-08 18:25:26'),
(360, '111', 'District', NULL, NULL, NULL, NULL, 'DT2023-00000253', 'S2020-00000019', '2024-02-08 18:25:26'),
(361, '111', 'District', NULL, NULL, NULL, NULL, 'DT2023-00000254', 'S2020-00000019', '2024-02-08 18:25:26'),
(447, 'V2024-00000025', 'District', NULL, NULL, NULL, NULL, 'DT2023-00000001', 'S2020-00000002', '2024-02-09 11:58:43'),
(461, 'V2024-00000041', 'PostalCode', NULL, NULL, NULL, 'PC2023-0014894', 'DT2023-00000490', 'S2020-00000035', '2024-02-09 17:24:48'),
(462, 'V2024-00000041', 'PostalCode', NULL, NULL, NULL, 'PC2023-0014802', 'DT2023-00000490', 'S2020-00000035', '2024-02-09 17:24:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors_stock_point`
--

CREATE TABLE `tbl_vendors_stock_point` (
  `SNo` int(11) NOT NULL,
  `DetailID` varchar(50) DEFAULT NULL,
  `UUID` varchar(50) DEFAULT NULL,
  `VendorID` varchar(50) DEFAULT NULL,
  `PointName` varchar(150) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `PostalID` varchar(50) DEFAULT NULL,
  `CityID` varchar(50) DEFAULT NULL,
  `TalukID` varchar(50) DEFAULT NULL,
  `DistrictID` varchar(50) DEFAULT NULL,
  `StateID` varchar(50) DEFAULT NULL,
  `CountryID` varchar(50) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vendors_stock_point`
--

INSERT INTO `tbl_vendors_stock_point` (`SNo`, `DetailID`, `UUID`, `VendorID`, `PointName`, `Address`, `PostalID`, `CityID`, `TalukID`, `DistrictID`, `StateID`, `CountryID`, `CreatedOn`) VALUES
(6, '', '4556cc3d5973', '111', NULL, 'hfjfjchchx', '638501', 'CI2023-0115677', 'T2023-00007995', 'DT2023-00000500', 'S2020-00000035', 'C2020-00000101', '2024-02-08 17:35:49'),
(24, '', 'c05c06659508', 'V2024-00000025', NULL, 'gshcjjf', '638501', 'CI2023-0115677', 'T2023-00007995', 'DT2023-00000500', 'S2020-00000035', 'C2020-00000101', '2024-02-09 11:52:41'),
(31, '', 'e8ee6c661595', 'V2024-00000041', NULL, 'fhxb', '638001', 'CI2023-0115684', 'T2023-00007995', 'DT2023-00000500', 'S2020-00000035', 'C2020-00000101', '2024-02-09 18:17:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors_supply`
--

CREATE TABLE `tbl_vendors_supply` (
  `DetailID` int(11) NOT NULL,
  `VendorID` varchar(50) DEFAULT NULL,
  `PCID` varchar(50) DEFAULT NULL,
  `PSCID` varchar(50) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vendors_supply`
--

INSERT INTO `tbl_vendors_supply` (`DetailID`, `VendorID`, `PCID`, `PSCID`, `CreatedOn`) VALUES
(39, '1112', 'PC2024-0000005', 'PSC2024-0000031', '2024-02-08 17:01:17'),
(40, '1112', 'PC2024-0000005', 'PSC2024-0000032', '2024-02-08 17:01:17'),
(65, '111', 'PC2024-0000005', 'PSC2024-0000031', '2024-02-08 17:28:06'),
(66, '111', 'PC2024-0000005', 'PSC2024-0000032', '2024-02-08 17:28:06'),
(155, 'V2024-00000025', 'PC2024-0000005', 'PSC2024-0000031', '2024-02-09 11:59:36'),
(156, 'V2024-00000025', 'PC2024-0000005', 'PSC2024-0000032', '2024-02-09 11:59:36'),
(241, 'V2024-00000041', 'PC2024-0000005', 'PSC2024-0000031', '2024-02-10 09:44:44'),
(242, 'V2024-00000041', 'PC2024-0000005', 'PSC2024-0000032', '2024-02-10 09:44:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors_vehicle`
--

CREATE TABLE `tbl_vendors_vehicle` (
  `SNo` int(11) NOT NULL,
  `VendorID` varchar(50) DEFAULT NULL,
  `VehicleID` varchar(50) DEFAULT NULL,
  `UUID` varchar(150) DEFAULT NULL,
  `VNumber` varchar(50) DEFAULT NULL,
  `VType` varchar(50) DEFAULT NULL,
  `VBrand` varchar(50) DEFAULT NULL,
  `VModel` varchar(50) DEFAULT NULL,
  `VLength` varchar(50) DEFAULT NULL,
  `VDepth` varchar(50) DEFAULT NULL,
  `VWidth` varchar(50) DEFAULT NULL,
  `VCapacity` varchar(50) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vendors_vehicle`
--

INSERT INTO `tbl_vendors_vehicle` (`SNo`, `VendorID`, `VehicleID`, `UUID`, `VNumber`, `VType`, `VBrand`, `VModel`, `VLength`, `VDepth`, `VWidth`, `VCapacity`, `CreatedOn`) VALUES
(6, '111', '', '56c34515d5c8', 'hfhfhf', 'VT2023-000004', 'VB2023-000002', 'VM2023-000006', '10', '5', '5', '5', '2024-02-08 17:46:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors_vehicle_images`
--

CREATE TABLE `tbl_vendors_vehicle_images` (
  `SNo` int(11) NOT NULL,
  `SLNo` varchar(50) DEFAULT NULL,
  `VendorID` varchar(50) DEFAULT NULL,
  `VehicleID` varchar(50) DEFAULT NULL,
  `UUID` varchar(150) DEFAULT NULL,
  `ImgID` varchar(50) DEFAULT NULL,
  `gImage` text DEFAULT NULL,
  `CreatedOn` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vendors_vehicle_images`
--

INSERT INTO `tbl_vendors_vehicle_images` (`SNo`, `SLNo`, `VendorID`, `VehicleID`, `UUID`, `ImgID`, `gImage`, `CreatedOn`) VALUES
(9, NULL, '111', '', '56c34515d5c8', NULL, 'O:8:\"stdClass\":3:{s:10:\"uploadPath\";s:61:\"uploads/tmp/20240208/0e2f046334d4bc38f37f486165c3686e-tmp.jpg\";s:8:\"fileName\";s:36:\"0e2f046334d4bc38f37f486165c3686e.jpg\";s:3:\"ext\";s:3:\"jpg\";}', '2024-02-08 17:46:29'),
(10, NULL, '111', '', '56c34515d5c8', NULL, 'O:8:\"stdClass\":3:{s:10:\"uploadPath\";s:61:\"uploads/tmp/20240208/c16a595e11aa31bd11e13b5371f771cd-tmp.jpg\";s:8:\"fileName\";s:36:\"c16a595e11aa31bd11e13b5371f771cd.jpg\";s:3:\"ext\";s:3:\"jpg\";}', '2024-02-08 17:46:29'),
(11, NULL, '111', '', '56c34515d5c8', NULL, 'O:8:\"stdClass\":3:{s:10:\"uploadPath\";s:61:\"uploads/tmp/20240208/fe2f347112a1c670c691c60d9e8fec53-tmp.png\";s:8:\"fileName\";s:36:\"fe2f347112a1c670c691c60d9e8fec53.png\";s:3:\"ext\";s:3:\"png\";}', '2024-02-08 17:46:29'),
(12, NULL, '111', '', '56c34515d5c8', NULL, 'O:8:\"stdClass\":3:{s:10:\"uploadPath\";s:61:\"uploads/tmp/20240208/9d34cee3d5a6d51c28ee76f16ef4ff12-tmp.png\";s:8:\"fileName\";s:36:\"9d34cee3d5a6d51c28ee76f16ef4ff12.png\";s:3:\"ext\";s:3:\"png\";}', '2024-02-08 17:46:29'),
(13, NULL, '111', '', '56c34515d5c8', NULL, 'O:8:\"stdClass\":3:{s:10:\"uploadPath\";s:61:\"uploads/tmp/20240208/a71411d80db59f2c08819aadd74c9348-tmp.png\";s:8:\"fileName\";s:36:\"a71411d80db59f2c08819aadd74c9348.png\";s:3:\"ext\";s:3:\"png\";}', '2024-02-08 17:46:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `tbl_products_variation`
--
ALTER TABLE `tbl_products_variation`
  ADD PRIMARY KEY (`VariationID`);

--
-- Indexes for table `tbl_product_save_status`
--
ALTER TABLE `tbl_product_save_status`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `tbl_vendors`
--
ALTER TABLE `tbl_vendors`
  ADD PRIMARY KEY (`VendorID`);

--
-- Indexes for table `tbl_vendors_service_locations`
--
ALTER TABLE `tbl_vendors_service_locations`
  ADD PRIMARY KEY (`SNo`);

--
-- Indexes for table `tbl_vendors_stock_point`
--
ALTER TABLE `tbl_vendors_stock_point`
  ADD PRIMARY KEY (`SNo`);

--
-- Indexes for table `tbl_vendors_supply`
--
ALTER TABLE `tbl_vendors_supply`
  ADD PRIMARY KEY (`DetailID`);

--
-- Indexes for table `tbl_vendors_vehicle`
--
ALTER TABLE `tbl_vendors_vehicle`
  ADD PRIMARY KEY (`SNo`);

--
-- Indexes for table `tbl_vendors_vehicle_images`
--
ALTER TABLE `tbl_vendors_vehicle_images`
  ADD PRIMARY KEY (`SNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_vendors_service_locations`
--
ALTER TABLE `tbl_vendors_service_locations`
  MODIFY `SNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=627;

--
-- AUTO_INCREMENT for table `tbl_vendors_stock_point`
--
ALTER TABLE `tbl_vendors_stock_point`
  MODIFY `SNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tbl_vendors_supply`
--
ALTER TABLE `tbl_vendors_supply`
  MODIFY `DetailID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=426;

--
-- AUTO_INCREMENT for table `tbl_vendors_vehicle`
--
ALTER TABLE `tbl_vendors_vehicle`
  MODIFY `SNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_vendors_vehicle_images`
--
ALTER TABLE `tbl_vendors_vehicle_images`
  MODIFY `SNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
