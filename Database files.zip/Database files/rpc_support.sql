-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2024 at 12:24 PM
-- Server version: 11.3.0-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rpc_support`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attachment`
--

CREATE TABLE `tbl_attachment` (
  `AttachmentID` varchar(50) NOT NULL,
  `ReferID` varchar(50) DEFAULT NULL,
  `Module` varchar(100) DEFAULT NULL,
  `UploadDir` text DEFAULT NULL,
  `UploadFileName` text DEFAULT NULL,
  `UploadFileExt` varchar(30) DEFAULT NULL,
  `UploadUrl` text DEFAULT NULL,
  `FileSize` varchar(100) NOT NULL DEFAULT '0',
  `DFlag` int(11) DEFAULT 0,
  `UserID` varchar(50) NOT NULL,
  `CreatedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdatedOn` timestamp NULL DEFAULT NULL,
  `DeletedOn` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `tbl_attachment`
--

INSERT INTO `tbl_attachment` (`AttachmentID`, `ReferID`, `Module`, `UploadDir`, `UploadFileName`, `UploadFileExt`, `UploadUrl`, `FileSize`, `DFlag`, `UserID`, `CreatedOn`, `UpdatedOn`, `DeletedOn`) VALUES
('SA2324-00000001', 'SD2324-00000002', 'Support', 'uploads/support/S2324-00000002/', 'f76a2e979d04bf626363296f470d88a6.JPG', 'JPG', 'uploads/support/S2324-00000002/f76a2e979d04bf626363296f470d88a6.JPG', '777817', 0, 'U2023-0000001', '2024-02-15 13:06:57', NULL, NULL),
('SA2324-00000002', 'SD2324-00000004', 'Support', 'uploads/support/S2324-00000003/', 'f76d5cf866c1c505e702aea4f0e42b36.jpg', 'jpg', 'uploads/support/S2324-00000003/f76d5cf866c1c505e702aea4f0e42b36.jpg', '391357', 0, 'U2023-0000001', '2024-02-21 04:36:20', NULL, NULL),
('SA2324-00000003', 'SD2324-00000004', 'Support', 'uploads/support/S2324-00000003/', 'a32812a263d3363aad8e1df912905e3d.jpg', 'jpg', 'uploads/support/S2324-00000003/a32812a263d3363aad8e1df912905e3d.jpg', '391357', 0, 'U2023-0000001', '2024-02-21 04:36:20', NULL, NULL),
('SA2324-00000004', 'SD2324-00000006', 'Support', 'uploads/support/S2324-00000003/', '49b9c7f2429c73c07ff2d1014c68921f.png', 'png', 'uploads/support/S2324-00000003/49b9c7f2429c73c07ff2d1014c68921f.png', '237389', 0, 'U2023-0000001', '2024-02-21 04:39:17', NULL, NULL),
('SA2324-00000005', 'SD2324-00000007', 'Support', 'uploads/support/S2324-00000004/', 'db8c3efe8478e3e8c2e428f04cc6c956.jpeg', 'jpeg', 'uploads/support/S2324-00000004/db8c3efe8478e3e8c2e428f04cc6c956.jpeg', '53976', 0, 'U2023-0000001', '2024-03-11 09:28:41', NULL, NULL),
('SA2324-00000006', 'SD2324-00000007', 'Support', 'uploads/support/S2324-00000004/', '2a80a48a7f8ce7265f7cb15596a164db.jpg', 'jpg', 'uploads/support/S2324-00000004/2a80a48a7f8ce7265f7cb15596a164db.jpg', '174628', 0, 'U2023-0000001', '2024-03-11 09:28:41', NULL, NULL),
('SA2324-00000007', 'SD2324-00000007', 'Support', 'uploads/support/S2324-00000004/', '7c5ed428d8d513c30cf518b5fb961dc5.pdf', 'pdf', 'uploads/support/S2324-00000004/7c5ed428d8d513c30cf518b5fb961dc5.pdf', '13264', 0, 'U2023-0000001', '2024-03-11 09:28:41', NULL, NULL),
('SA2324-00000008', 'SD2324-00000008', 'Support', 'uploads/support/S2324-00000005/', '57b724e3e832a7a30e7bc26e085c08f4.jpg', 'jpg', 'uploads/support/S2324-00000005/57b724e3e832a7a30e7bc26e085c08f4.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 11:41:57', NULL, NULL),
('SA2324-00000009', 'SD2324-00000008', 'Support', 'uploads/support/S2324-00000005/', '2ad07e6ff56d286db5ae0a24a18ee290.jpg', 'jpg', 'uploads/support/S2324-00000005/2ad07e6ff56d286db5ae0a24a18ee290.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 11:41:57', NULL, NULL),
('SA2324-00000010', 'SD2324-00000009', 'Support', 'uploads/support/S2324-00000005/', '0695ca6317272929311bb9cd074eb2c7.jpg', 'jpg', 'uploads/support/S2324-00000005/0695ca6317272929311bb9cd074eb2c7.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 11:44:41', NULL, NULL),
('SA2324-00000011', 'SD2324-00000009', 'Support', 'uploads/support/S2324-00000005/', '199c507ddeaaa90fc6f988ae14ad06b1.jpg', 'jpg', 'uploads/support/S2324-00000005/199c507ddeaaa90fc6f988ae14ad06b1.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 11:44:41', NULL, NULL),
('SA2324-00000012', 'SD2324-00000014', 'Support', 'uploads/support/S2324-00000009/', '7e231c7cbe92728036b27e62a0aa691a.jpg', 'jpg', 'uploads/support/S2324-00000009/7e231c7cbe92728036b27e62a0aa691a.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 12:30:22', NULL, NULL),
('SA2324-00000013', 'SD2324-00000014', 'Support', 'uploads/support/S2324-00000009/', '637f1fb74d0183f89640e96655acb9d9.jpg', 'jpg', 'uploads/support/S2324-00000009/637f1fb74d0183f89640e96655acb9d9.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 12:30:22', NULL, NULL),
('SA2324-00000014', 'SD2324-00000016', 'Support', 'uploads/support/S2324-00000009/', '3a0e4edcf88dc8538cd4171c76598865.jpg', 'jpg', 'uploads/support/S2324-00000009/3a0e4edcf88dc8538cd4171c76598865.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 12:32:38', NULL, NULL),
('SA2324-00000015', 'SD2324-00000016', 'Support', 'uploads/support/S2324-00000009/', '6c4dd387917a4483624ddaf67293bdc7.jpg', 'jpg', 'uploads/support/S2324-00000009/6c4dd387917a4483624ddaf67293bdc7.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 12:32:38', NULL, NULL),
('SA2324-00000016', 'SD2324-00000018', 'Support', 'uploads/support/S2324-00000009/', 'beca3b765ebac7cb0b513222b2e85e29.jpg', 'jpg', 'uploads/support/S2324-00000009/beca3b765ebac7cb0b513222b2e85e29.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 12:59:24', NULL, NULL),
('SA2324-00000017', 'SD2324-00000018', 'Support', 'uploads/support/S2324-00000009/', 'e29e44f1c541db7fc6e5a2c99191c1d9.jpg', 'jpg', 'uploads/support/S2324-00000009/e29e44f1c541db7fc6e5a2c99191c1d9.jpg', '1448170', 0, 'U2324-0000010', '2024-03-11 12:59:24', NULL, NULL),
('SA2324-00000018', 'SD2324-00000019', 'Support', 'uploads/support/S2324-00000011/', '67368110babc6cef9230469f0a9550ac.jpg', 'jpg', 'uploads/support/S2324-00000011/67368110babc6cef9230469f0a9550ac.jpg', '1448170', 0, 'U2324-0000010', '2024-03-12 04:51:52', NULL, NULL),
('SA2324-00000019', 'SD2324-00000026', 'Support', 'uploads/support/S2324-00000012/', 'bb8b3589c55e10b41927984be838d151.jpg', 'jpg', 'uploads/support/S2324-00000012/bb8b3589c55e10b41927984be838d151.jpg', '32410', 0, 'U2324-0000008', '2024-03-12 09:53:04', NULL, NULL),
('SA2324-00000020', 'SD2324-00000027', 'Support', 'uploads/support/S2324-00000014/', '9fa73aa45e3082288c6820df14909fb5.jpg', 'jpg', 'uploads/support/S2324-00000014/9fa73aa45e3082288c6820df14909fb5.jpg', '32410', 0, 'U2324-0000008', '2024-03-12 09:53:49', NULL, NULL),
('SA2324-00000021', 'SD2324-00000028', 'Support', 'uploads/support/S2324-00000014/', '3157483aad73037368e035f97be0ca4d.jpg', 'jpg', 'uploads/support/S2324-00000014/3157483aad73037368e035f97be0ca4d.jpg', '32410', 0, 'U2324-0000008', '2024-03-12 10:06:12', NULL, NULL),
('SA2324-00000022', 'SD2324-00000028', 'Support', 'uploads/support/S2324-00000014/', 'cf1f21584482b11f5d4866184e15b6fe.jpg', 'jpg', 'uploads/support/S2324-00000014/cf1f21584482b11f5d4866184e15b6fe.jpg', '35603', 0, 'U2324-0000008', '2024-03-12 10:06:12', NULL, NULL),
('SA2324-00000023', 'SD2324-00000028', 'Support', 'uploads/support/S2324-00000014/', 'd291abe56151e096dc3f59d2c40731e1.png', 'png', 'uploads/support/S2324-00000014/d291abe56151e096dc3f59d2c40731e1.png', '13088', 0, 'U2324-0000008', '2024-03-12 10:06:12', NULL, NULL),
('SA2324-00000024', 'SD2324-00000028', 'Support', 'uploads/support/S2324-00000014/', '9ee3a996d6d619d6ec70033ff01fde6f.png', 'png', 'uploads/support/S2324-00000014/9ee3a996d6d619d6ec70033ff01fde6f.png', '11916', 0, 'U2324-0000008', '2024-03-12 10:06:12', NULL, NULL),
('SA2324-00000025', 'SD2324-00000029', 'Support', 'uploads/support/S2324-00000014/', 'ee8dc6bb6a28bd82ea973e3fea926696.jpg', 'jpg', 'uploads/support/S2324-00000014/ee8dc6bb6a28bd82ea973e3fea926696.jpg', '32410', 0, 'U2324-0000008', '2024-03-12 10:07:44', NULL, NULL),
('SA2324-00000026', 'SD2324-00000029', 'Support', 'uploads/support/S2324-00000014/', 'af9a326bdbf549e018076ab6b9f693aa.jpg', 'jpg', 'uploads/support/S2324-00000014/af9a326bdbf549e018076ab6b9f693aa.jpg', '35603', 0, 'U2324-0000008', '2024-03-12 10:07:44', NULL, NULL),
('SA2324-00000027', 'SD2324-00000029', 'Support', 'uploads/support/S2324-00000014/', '044bb5f9c6458418fa036eba0f840ccb.png', 'png', 'uploads/support/S2324-00000014/044bb5f9c6458418fa036eba0f840ccb.png', '13088', 0, 'U2324-0000008', '2024-03-12 10:07:44', NULL, NULL),
('SA2324-00000028', 'SD2324-00000029', 'Support', 'uploads/support/S2324-00000014/', 'ec09f71afd0288e9a7927f298d8bf143.png', 'png', 'uploads/support/S2324-00000014/ec09f71afd0288e9a7927f298d8bf143.png', '11916', 0, 'U2324-0000008', '2024-03-12 10:07:44', NULL, NULL),
('SA2324-00000029', 'SD2324-00000030', 'Support', 'uploads/support/S2324-00000014/', '3459c484fc7726d0db277c93b7cf6e34.jpg', 'jpg', 'uploads/support/S2324-00000014/3459c484fc7726d0db277c93b7cf6e34.jpg', '308973', 0, 'U2324-0000008', '2024-03-12 10:16:18', NULL, NULL),
('SA2324-00000030', 'SD2324-00000030', 'Support', 'uploads/support/S2324-00000014/', 'efa66f1b6d0c9b311846af408b017f6c.jpg', 'jpg', 'uploads/support/S2324-00000014/efa66f1b6d0c9b311846af408b017f6c.jpg', '391357', 0, 'U2324-0000008', '2024-03-12 10:16:18', NULL, NULL),
('SA2324-00000031', 'SD2324-00000030', 'Support', 'uploads/support/S2324-00000014/', '9d1d4c06e09ee7efc7d2452851d2d92e.jpg', 'jpg', 'uploads/support/S2324-00000014/9d1d4c06e09ee7efc7d2452851d2d92e.jpg', '268231', 0, 'U2324-0000008', '2024-03-12 10:16:18', NULL, NULL),
('SA2324-00000032', 'SD2324-00000030', 'Support', 'uploads/support/S2324-00000014/', '31d28abe057d415b2c0a0b24095744af.jpg', 'jpg', 'uploads/support/S2324-00000014/31d28abe057d415b2c0a0b24095744af.jpg', '74804', 0, 'U2324-0000008', '2024-03-12 10:16:18', NULL, NULL),
('SA2324-00000033', 'SD2324-00000031', 'Support', 'uploads/support/S2324-00000014/', '86ade3c0db9037e5c0002805403144eb.jpg', 'jpg', 'uploads/support/S2324-00000014/86ade3c0db9037e5c0002805403144eb.jpg', '308973', 0, 'U2324-0000008', '2024-03-12 10:17:08', NULL, NULL),
('SA2324-00000034', 'SD2324-00000031', 'Support', 'uploads/support/S2324-00000014/', '6aeb10c4abcf4e0cf99ef415e802b5f1.jpg', 'jpg', 'uploads/support/S2324-00000014/6aeb10c4abcf4e0cf99ef415e802b5f1.jpg', '391357', 0, 'U2324-0000008', '2024-03-12 10:17:08', NULL, NULL),
('SA2324-00000035', 'SD2324-00000031', 'Support', 'uploads/support/S2324-00000014/', 'cc01af93782816edbc4c4b0db6c034d9.jpg', 'jpg', 'uploads/support/S2324-00000014/cc01af93782816edbc4c4b0db6c034d9.jpg', '268231', 0, 'U2324-0000008', '2024-03-12 10:17:08', NULL, NULL),
('SA2324-00000036', 'SD2324-00000031', 'Support', 'uploads/support/S2324-00000014/', '3506a3787c559f1554e2050c0b9134c9.jpg', 'jpg', 'uploads/support/S2324-00000014/3506a3787c559f1554e2050c0b9134c9.jpg', '74804', 0, 'U2324-0000008', '2024-03-12 10:17:08', NULL, NULL),
('SA2324-00000037', 'SD2324-00000032', 'Support', 'uploads/support/S2324-00000015/', 'afd4797ea0494ab397098c61b0d64652.jpg', 'jpg', 'uploads/support/S2324-00000015/afd4797ea0494ab397098c61b0d64652.jpg', '35603', 0, 'U2324-0000008', '2024-03-12 10:45:04', NULL, NULL),
('SA2324-00000038', 'SD2324-00000032', 'Support', 'uploads/support/S2324-00000015/', '202e39f85de98e39bc28f9cd59502af9.jpg', 'jpg', 'uploads/support/S2324-00000015/202e39f85de98e39bc28f9cd59502af9.jpg', '35603', 0, 'U2324-0000008', '2024-03-12 10:45:04', NULL, NULL),
('SA2324-00000039', 'SD2324-00000032', 'Support', 'uploads/support/S2324-00000015/', '19c278f4870c232817c6eea0ddcb6f91.jpg', 'jpg', 'uploads/support/S2324-00000015/19c278f4870c232817c6eea0ddcb6f91.jpg', '32410', 0, 'U2324-0000008', '2024-03-12 10:45:04', NULL, NULL),
('SA2324-00000040', 'SD2324-00000033', 'Support', 'uploads/support/S2324-00000015/', '45d3a3a42303b4a341aeafa4f1aff2ae.jpg', 'jpg', 'uploads/support/S2324-00000015/45d3a3a42303b4a341aeafa4f1aff2ae.jpg', '96057', 0, 'U2023-0000001', '2024-03-12 10:45:37', NULL, NULL),
('SA2324-00000041', 'SD2324-00000034', 'Support', 'uploads/support/S2324-00000015/', '2fab4e43d3868ea6f38218ce9622fe0a.jpg', 'jpg', 'uploads/support/S2324-00000015/2fab4e43d3868ea6f38218ce9622fe0a.jpg', '6486', 0, 'U2324-0000008', '2024-03-12 10:49:20', NULL, NULL),
('SA2324-00000042', 'SD2324-00000035', 'Support', 'uploads/support/S2324-00000015/', '0f208f2239af9e8d5d0a3ba15bb6d3ae.png', 'png', 'uploads/support/S2324-00000015/0f208f2239af9e8d5d0a3ba15bb6d3ae.png', '406805', 0, 'U2023-0000001', '2024-03-12 12:12:50', NULL, NULL),
('SA2324-00000043', 'SD2324-00000037', 'Support', 'uploads/support/S2324-00000012/', '2a40dd6829b225ac2fe773c5a40c96f6.jpg', 'jpg', 'uploads/support/S2324-00000012/2a40dd6829b225ac2fe773c5a40c96f6.jpg', '32410', 0, 'U2324-0000008', '2024-03-13 04:57:09', NULL, NULL),
('SA2324-00000044', 'SD2324-00000042', 'Support', 'uploads/support/S2324-00000017/', '9744047dd52f11c7e0abb8371309aa85.jpg', 'jpg', 'uploads/support/S2324-00000017/9744047dd52f11c7e0abb8371309aa85.jpg', '391357', 0, 'U2324-0000010', '2024-03-13 09:14:35', NULL, NULL),
('SA2324-00000045', 'SD2324-00000042', 'Support', 'uploads/support/S2324-00000017/', 'f42cd848c1d5c9e3bf968a9bf5f3dec1.jpg', 'jpg', 'uploads/support/S2324-00000017/f42cd848c1d5c9e3bf968a9bf5f3dec1.jpg', '267304', 0, 'U2324-0000010', '2024-03-13 09:14:35', NULL, NULL),
('SA2324-00000046', 'SD2324-00000042', 'Support', 'uploads/support/S2324-00000017/', '6d88741f5766be434c35aa15d41ba143.jpg', 'jpg', 'uploads/support/S2324-00000017/6d88741f5766be434c35aa15d41ba143.jpg', '32410', 0, 'U2324-0000010', '2024-03-13 09:14:35', NULL, NULL),
('SA2324-00000047', 'SD2324-00000042', 'Support', 'uploads/support/S2324-00000017/', 'f7d4cc9a0f09cf2002481b765cedb2ad.jpg', 'jpg', 'uploads/support/S2324-00000017/f7d4cc9a0f09cf2002481b765cedb2ad.jpg', '288885', 0, 'U2324-0000010', '2024-03-13 09:14:35', NULL, NULL),
('SA2324-00000048', 'SD2324-00000043', 'Support', 'uploads/support/S2324-00000018/', 'e3980dc36fb5d0f55e646291d77e4284.jpg', 'jpg', 'uploads/support/S2324-00000018/e3980dc36fb5d0f55e646291d77e4284.jpg', '288885', 0, 'U2324-0000010', '2024-03-13 09:23:53', NULL, NULL),
('SA2324-00000049', 'SD2324-00000044', 'Support', 'uploads/support/S2324-00000019/', '7d4601b87edddef31945422a0208fa28.jpg', 'jpg', 'uploads/support/S2324-00000019/7d4601b87edddef31945422a0208fa28.jpg', '175322', 0, 'U2324-0000027', '2024-03-15 05:15:30', NULL, NULL),
('SA2324-00000050', 'SD2324-00000045', 'Support', 'uploads/support/S2324-00000019/', '3d106e288c5e750b08978b87858fd3c8.jpg', 'jpg', 'uploads/support/S2324-00000019/3d106e288c5e750b08978b87858fd3c8.jpg', '427457', 0, 'U2324-0000027', '2024-03-15 05:16:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_support`
--

CREATE TABLE `tbl_support` (
  `SupportID` varchar(50) NOT NULL,
  `UserID` varchar(50) DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `SupportType` varchar(50) DEFAULT NULL,
  `TicketFor` enum('Vendor','Customer') DEFAULT NULL,
  `Priority` enum('Low','Medium','High') DEFAULT 'Low',
  `Status` enum('New','Opened','Closed') DEFAULT 'New',
  `DFlag` int(11) DEFAULT 0,
  `CreatedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdatedOn` timestamp NULL DEFAULT NULL,
  `DeletedOn` timestamp NULL DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  `DeletedBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_support`
--

INSERT INTO `tbl_support` (`SupportID`, `UserID`, `Subject`, `SupportType`, `TicketFor`, `Priority`, `Status`, `DFlag`, `CreatedOn`, `UpdatedOn`, `DeletedOn`, `CreatedBy`, `UpdatedBy`, `DeletedBy`) VALUES
('S2324-00000002', 'U2023-0000004', 'asdfasdf', 'ST2023-00002', 'Vendor', 'Low', 'New', 0, '2024-02-15 13:06:57', '2024-03-12 12:12:50', NULL, 'U2023-0000001', 'U2023-0000001', NULL),
('S2324-00000003', 'U2023-0000004', 'Vehicle Model is Not Available', 'ST2023-00003', 'Vendor', 'High', 'New', 0, '2024-02-21 04:36:20', '2024-03-12 12:12:50', NULL, 'U2023-0000001', 'U2023-0000001', NULL),
('S2324-00000004', 'U2324-0000005', 'Postal Code is not available', 'ST2023-00002', NULL, 'High', 'New', 0, '2024-03-11 09:28:41', '2024-03-12 12:12:50', NULL, 'U2023-0000001', NULL, NULL),
('S2324-00000005', 'U2324-0000010', 'Products', 'ST2023-00002', 'Customer', 'High', 'Opened', 0, '2024-03-11 11:41:57', '2024-03-12 12:12:50', NULL, 'U2324-0000010', NULL, NULL),
('S2324-00000009', 'U2324-0000010', 'Categories Not visible', 'ST2023-00002', 'Customer', 'High', 'New', 0, '2024-03-11 12:30:22', '2024-03-12 12:12:50', NULL, 'U2324-0000010', NULL, NULL),
('S2324-00000010', 'U2324-0000010', 'hello', 'ST2023-00002', 'Customer', 'Low', 'New', 0, '2024-03-11 12:51:23', '2024-03-12 12:12:50', NULL, 'U2324-0000010', NULL, NULL),
('S2324-00000011', 'U2324-0000010', 'Order cant be viewed', 'ST2023-00002', 'Customer', 'High', 'New', 0, '2024-03-12 04:51:52', '2024-03-12 12:12:50', NULL, 'U2324-0000010', NULL, NULL),
('S2324-00000015', 'U2324-0000008', 'testibg1', 'ST2023-00002', NULL, 'Low', 'Opened', 0, '2024-03-12 10:45:03', '2024-03-12 12:18:00', NULL, 'U2324-0000008', 'U2023-0000001', NULL),
('S2324-00000017', 'U2324-0000010', 'cyhcydyd', 'ST2023-00002', 'Customer', 'Low', 'Opened', 0, '2024-03-13 09:09:25', '2024-03-13 10:24:54', NULL, 'U2324-0000010', 'U2023-0000001', NULL),
('S2324-00000018', 'U2324-0000010', 'vvtrcrcrvtvtvyvyvyv', 'ST2023-00002', 'Customer', 'Low', 'Opened', 0, '2024-03-13 09:23:53', '2024-03-13 10:35:19', NULL, 'U2324-0000010', 'U2023-0000001', NULL),
('S2324-00000019', 'U2324-0000027', 'orders issue', 'ST2023-00004', 'Customer', 'High', 'New', 0, '2024-03-15 05:15:30', NULL, NULL, 'U2324-0000027', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_support_details`
--

CREATE TABLE `tbl_support_details` (
  `SLNO` varchar(50) NOT NULL DEFAULT '',
  `UserID` varchar(50) DEFAULT NULL,
  `SupportID` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `DeliveryStatus` int(11) NOT NULL DEFAULT 0,
  `ReadStatus` int(11) NOT NULL DEFAULT 0,
  `DFlag` int(11) DEFAULT 0,
  `CreatedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdatedOn` timestamp NULL DEFAULT NULL,
  `DeletedOn` timestamp NULL DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  `DeletedBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_support_details`
--

INSERT INTO `tbl_support_details` (`SLNO`, `UserID`, `SupportID`, `Description`, `DeliveryStatus`, `ReadStatus`, `DFlag`, `CreatedOn`, `UpdatedOn`, `DeletedOn`, `CreatedBy`, `UpdatedBy`, `DeletedBy`) VALUES
('SD2024-00000001', 'C2024-00000002', 'S2024-00000001', 'hfuf', 0, 0, 0, '2024-01-08 05:36:13', NULL, NULL, 'C2024-00000002', NULL, NULL),
('SD2024-00000002', 'C2024-00000002', 'S2024-00000001', 'hfhfufuf', 0, 0, 0, '2024-01-08 05:36:50', NULL, NULL, 'C2024-00000002', NULL, NULL),
('SD2324-00000002', 'U2023-0000001', 'S2324-00000002', 'asdfasdf', 0, 0, 0, '2024-02-15 13:06:57', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000003', 'U2023-0000001', 'S2324-00000002', 'thank you', 0, 0, 0, '2024-02-15 13:11:18', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000004', 'U2023-0000001', 'S2324-00000003', 'Some Vehicle Models are not available in the vehicle models for Ashok Leyland drop downs.', 0, 0, 0, '2024-02-21 04:36:20', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000005', 'U2023-0000001', 'S2324-00000003', 'Thank you. will add some vehicle models and let you know sir.', 0, 0, 0, '2024-02-21 04:38:18', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000006', 'U2023-0000001', 'S2324-00000003', 'Added some models. kindly check in your app sir.', 0, 0, 0, '2024-02-21 04:39:17', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000007', 'U2023-0000001', 'S2324-00000004', '625601 is not available', 0, 0, 0, '2024-03-11 09:28:41', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000008', 'U2324-0000010', 'S2324-00000005', '\"asdfasdfasdfasd\"', 0, 0, 0, '2024-03-11 11:41:57', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000009', 'U2324-0000010', 'S2324-00000005', 'Hello', 0, 0, 0, '2024-03-11 11:44:41', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000010', 'U2324-0000010', 'S2324-00000005', 'Hello', 0, 0, 0, '2024-03-11 12:13:10', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000011', 'U2324-0000010', 'S2324-00000006', 'Hello', 0, 0, 0, '2024-03-11 12:23:16', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000012', 'U2324-0000010', 'S2324-00000007', 'Hello', 0, 0, 0, '2024-03-11 12:29:03', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000013', 'U2324-0000010', 'S2324-00000008', 'Hello', 0, 0, 0, '2024-03-11 12:29:05', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000014', 'U2324-0000010', 'S2324-00000009', 'Imp Issue', 0, 0, 0, '2024-03-11 12:30:22', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000015', 'U2023-0000001', 'S2324-00000009', 'Can u please explain the issue?', 0, 0, 0, '2024-03-11 12:31:55', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000016', 'U2324-0000010', 'S2324-00000009', 'Order page is not visible', 0, 0, 0, '2024-03-11 12:32:38', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000017', 'U2324-0000010', 'S2324-00000010', 'hello', 0, 0, 0, '2024-03-11 12:51:23', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000018', 'U2324-0000010', 'S2324-00000009', 'Order page is not visible', 0, 0, 0, '2024-03-11 12:59:24', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000019', 'U2324-0000010', 'S2324-00000011', 'I cannot able to view the order page and filter the details', 0, 0, 0, '2024-03-12 04:51:52', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000020', 'U2324-0000008', 'S2324-00000012', 'hvj', 0, 0, 0, '2024-03-12 06:10:34', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000021', 'U2324-0000008', 'S2324-00000013', 'fudttjg utbrbbur uuv5gur tuhr', 0, 0, 0, '2024-03-12 09:42:23', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000022', 'U2324-0000008', 'S2324-00000012', 'iyiycyic yf', 0, 0, 0, '2024-03-12 09:43:36', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000023', 'U2324-0000008', 'S2324-00000012', 'gjjvhcch urb bd6ve6ijtbesi5d i5s 8e6 oydiy d  iysit di t fi doy d ko  o odd  iyfk u  iyy k ydd kydk ydk yeiy d k ie o6e iy eiy ys o do s', 0, 0, 0, '2024-03-12 09:49:43', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000024', 'U2324-0000008', 'S2324-00000012', 'gjjvhcch urb bd6ve6ijtbesi5d i5s 8e6 oydiy d  iysit di t fi doy d ko  o odd  iyfk u  iyy k ydd kydk ydk yeiy d k ie o6e iy eiy ys o do s', 0, 0, 0, '2024-03-12 09:49:51', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000025', 'U2324-0000008', 'S2324-00000012', 'hffhug', 0, 0, 0, '2024-03-12 09:50:58', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000026', 'U2324-0000008', 'S2324-00000012', 'jdjshshhsbbs dhsbbsbs jdjndb', 0, 0, 0, '2024-03-12 09:53:04', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000027', 'U2324-0000008', 'S2324-00000014', 'sansad dbhshs d dbhddbd  dhehhehehbtbbh ykkgkky y ykykynnyy ykkgm', 0, 0, 0, '2024-03-12 09:53:49', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000028', 'U2324-0000008', 'S2324-00000014', 'hello xjbd skkeie rufb f duidjr djdksm fufuhrhfbbfhfhfbb d fjdbbbf d jsmzjdriijd c dijdnrbd  xjdj d', 0, 0, 0, '2024-03-12 10:06:12', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000029', 'U2324-0000008', 'S2324-00000014', 'hello xjbd skkeie rufb f duidjr djdksm fufuhrhfbbfhfhfbb d fjdbbbf d jsmzjdriijd c dijdnrbd  xjdj d', 0, 0, 0, '2024-03-12 10:07:44', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000030', 'U2324-0000008', 'S2324-00000014', 'bil pi ouguo f fuo fuo fuokye 68ut st is tsj stu jt dk yissu5k dy iy sjt  iydi diydi ydiy di e8 5d iys5uwqwu  tksau 485 s i85e 68e iti ts85si 5s  iydi yd ydi ys it sti sit it d5isi tdditst 8sst istiutaaut s si ts itsuttsisuw6i si', 0, 0, 0, '2024-03-12 10:16:18', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000031', 'U2324-0000008', 'S2324-00000014', 'bil pi ouguo f fuo fuo fuokye 68ut st is tsj stu jt dk yissu5k dy iy sjt  iydi diydi ydiy di e8 5d iys5uwqwu  tksau 485 s i85e 68e iti ts85si 5s  iydi yd ydi ys it sti sit it d5isi tdditst 8sst istiutaaut s si ts itsuttsisuw6i si', 0, 0, 0, '2024-03-12 10:17:08', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000032', 'U2324-0000008', 'S2324-00000015', 'uvtd iyd iyiye  diy yoryir  ryi our way e everyone didn\'t jtd jt  su jdykyd  sut stiidt kye  ie didi id is ie dp i dp di  din de', 0, 0, 0, '2024-03-12 10:45:03', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000033', 'U2023-0000001', 'S2324-00000015', 'What is the issue?', 0, 0, 0, '2024-03-12 10:45:37', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000034', 'U2324-0000008', 'S2324-00000015', 'I need a new product added', 0, 0, 0, '2024-03-12 10:49:20', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000035', 'U2023-0000001', 'S2324-00000015', 'Soon, We will Update', 0, 0, 0, '2024-03-12 12:12:50', NULL, NULL, 'U2023-0000001', NULL, NULL),
('SD2324-00000036', 'U2324-0000008', 'S2324-00000015', 'tg', 0, 0, 0, '2024-03-13 04:54:15', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000037', 'U2324-0000008', 'S2324-00000012', 'cjjvuvydufu', 0, 0, 0, '2024-03-13 04:57:09', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000038', 'U2324-0000008', 'S2324-00000016', 'hcchfydy', 0, 0, 0, '2024-03-13 05:13:00', NULL, NULL, 'U2324-0000008', NULL, NULL),
('SD2324-00000039', 'U2324-0000010', 'S2324-00000017', 'hcch', 0, 0, 0, '2024-03-13 09:09:25', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000040', 'U2324-0000010', 'S2324-00000017', 'hello', 0, 0, 0, '2024-03-13 09:11:50', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000041', 'U2324-0000010', 'S2324-00000017', NULL, 0, 0, 0, '2024-03-13 09:11:53', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000042', 'U2324-0000010', 'S2324-00000017', 'gufy', 0, 0, 0, '2024-03-13 09:14:35', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000043', 'U2324-0000010', 'S2324-00000018', 'fhhfhd', 0, 0, 0, '2024-03-13 09:23:53', NULL, NULL, 'U2324-0000010', NULL, NULL),
('SD2324-00000044', 'U2324-0000027', 'S2324-00000019', 'orders are not getting placed', 0, 0, 0, '2024-03-15 05:15:30', NULL, NULL, 'U2324-0000027', NULL, NULL),
('SD2324-00000045', 'U2324-0000027', 'S2324-00000019', 'fixed, kindly remive it', 0, 0, 0, '2024-03-15 05:16:40', NULL, NULL, 'U2324-0000027', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_attachment`
--
ALTER TABLE `tbl_attachment`
  ADD PRIMARY KEY (`AttachmentID`),
  ADD KEY `AttachmentID` (`AttachmentID`,`ReferID`,`Module`);

--
-- Indexes for table `tbl_support`
--
ALTER TABLE `tbl_support`
  ADD PRIMARY KEY (`SupportID`),
  ADD KEY `SupportID` (`SupportID`,`UserID`,`Subject`,`Priority`,`Status`,`CreatedBy`,`UpdatedBy`,`DeletedBy`);

--
-- Indexes for table `tbl_support_details`
--
ALTER TABLE `tbl_support_details`
  ADD PRIMARY KEY (`SLNO`),
  ADD KEY `SLNO` (`SLNO`,`UserID`,`SupportID`,`CreatedBy`,`UpdatedBy`,`DeletedBy`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
